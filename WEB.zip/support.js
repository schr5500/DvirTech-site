/* =====================================================================
   DvirTech — שירות ותמיכה (support.html)
   =====================================================================
   רשימת השירותים מהמחירון + לוח פנייה שהשאלות בו משתנות לפי מה שנבחר.

   ⚠️ בחירה מרובה — האינטראקציה המרכזית של הדף
   -------------------------------------------
   אפשר לסמן ✓ כמה שירותים ולשלוח אותם בפנייה אחת, וגם ללחוץ "פנייה
   בוואטסאפ" על כרטיס בודד ולשלוח רק אותו. ההודעה המשולבת מציגה כל
   שירות בשורה משלו עם "+" בתחילתה, והתשובות שלו בשורות מתחתיו:

       היי דביר, אני מעוניין בשירותים הבאים:
       + אבחון תקלה — 150 ₪
          • מה קורה? — המסך נשאר שחור
       + ניקוי פנימי + משחה תרמית — 150 ₪

   ⚠️ אין ולא יהיה כאן סכום, עגלה או תשלום. השירותים אינם נרכשים בדף
   הזה — כל פנייה נסגרת מול דביר אישית. סכום בתחתית ההודעה היה הופך
   פנייה להזמנה מאושרת, וזה בדיוק מה שאסור.

   ⚠️ מקור המחירים והמק"טים
   ------------------------
   השמות והמחירים כאן הם העתק מדויק של PRICE_LIST ב-
   CRM+SUPPLIERS/2-pricelist-picker.gs, והמפתחות (key) והמק"טים (sku)
   הם אותם מפתחות בדיוק כמו ב-REAL_SUMIT_SKUS ב-4-payment-api.gs.
   זה לא מקרי: כשהדף הזה יחובר בעתיד להזמנה אמיתית, ה-key שנשמר ב-
   data-key על הכרטיס הוא כבר המפתח שהשרת יודע לתרגם למק"ט SUMIT.
   מחיר שמשתנה במחירון — לעדכן גם כאן.

   ⚠️ לא כל 24 השירותים שבמחירון מופיעים כאן. שלושה מהם הם תמחור פנימי
   ולא מוצר מדף, ולכן הושמטו במכוון:
     • CLI-4004 "הרכבה (כשקונים ממני חלקים)" ₪0 — הטבה אוטומטית שנוספת
       לעגלה דרך הבונה. כרטיס "לפנייה" ב-₪0 היה מזמין בקשות להרכבה
       חינם של חלקים שנקנו במקום אחר. מוצג כהערה בראש קטגוריית ההרכבה.
     • CLI-4005 "הרכבה מוזלת (כשקונים ממני חלקים)" ₪150 — מדרגת ביניים
       שנקבעת לפי כמה מהחלקים נקנו דרכנו. החלטה של דביר לכל מקרה.
     • CLI-4012 "נסיעה בלבד (מעל שעה וחצי)" ₪200 — תוספת נסיעה שנטענת
       על שירות אחר, לא שירות שמזמינים.

   ⚠️ השליחה היא וואטסאפ ולא endpoint. אין לטופס הזה שרת, וגם לא צריך:
   זו אותה דרך שכבר עובדת ב-contact.html, והפנייה מגיעה לדביר לטלפון
   מיד עם כל התשובות מסודרות בהודעה אחת.
===================================================================== */

const SUP_WHATSAPP_NUMBER = "972502000373";

function supEsc(s){
  return String(s == null ? "" : s)
    .replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;");
}
function supTr(he, en){ return (typeof LANG !== "undefined" && LANG === "en") ? en : he; }

/* ==================== קטגוריות ==================== */
/* אותן שש קטגוריות ובאותו סדר כמו במחירון. */
const SUP_CATS = [
  { key:"assembly", he:"הרכבה",        en:"Assembly",
    noteHe:"קנית את החלקים דרך האתר או דרכי? ההרכבה כלולה ללא עלות ומתווספת לעגלה מעצמה — אין צורך לפנות דרך כאן.",
    noteEn:"Bought the parts through the site? Assembly is included at no cost and is added to your cart automatically — no need to request it here." },
  { key:"os",       he:"מערכת הפעלה",  en:"Operating system" },
  { key:"visit",    he:"ביקור בית",    en:"Home visit",
    noteHe:"המחיר נקבע לפי זמן הנסיעה אליך. לא בטוח לאיזו מדרגה אתה שייך? בחר את הקרובה ביותר — בטופס תתבקש רק לציין את היישוב, ואני אאשר לך את המחיר המדויק לפני שנקבע.",
    noteEn:"The price depends on travel time to you. Not sure which tier fits? Pick the closest one — the form only asks for your town, and I'll confirm the exact price before we schedule." },
  { key:"support",  he:"תמיכה",        en:"Support" },
  { key:"repairs",  he:"תיקונים",      en:"Repairs" },
  { key:"bundles",  he:"חבילות",       en:"Bundles" }
];

/* ==================== שאלות משותפות ==================== */
/* שאלה שחוזרת בכמה שירותים מוגדרת פעם אחת — גם כדי שהניסוח יהיה זהה
   בכל מקום, וגם כדי שלא יהיו שתי גרסאות אנגלית לאותה שאלה. */
const SQ = {
  partsReady: { id:"partsReady", type:"select",
    he:"כל החלקים כבר אצלך?", en:"Do you already have all the parts?",
    options:[["הכל הגיע","Everything has arrived"],
             ["חלק מהחלקים הגיעו","Some of the parts have arrived"],
             ["עוד לא הזמנתי","I haven't ordered yet"]] },

  partsList: { id:"partsList", type:"textarea", opt:true, max:400,
    he:"אילו חלקים? (לא חובה, אבל עוזר לי להעריך זמן)",
    en:"Which parts? (optional — helps me estimate the time)",
    phHe:"מעבד, לוח אם, כרטיס מסך, קירור, מארז…",
    phEn:"CPU, motherboard, GPU, cooler, case…" },

  handover: { id:"handover", type:"select",
    he:"איך נעביר את המחשב?", en:"How should we hand over the PC?",
    options:[["אני מביא ואוסף","I'll drop it off and pick it up"],
             ["אשמח שתגיע אליי (ביקור בית — בתוספת תשלום)","I'd like you to come to me (home visit — extra charge)"],
             ["עוד לא יודע","Not sure yet"]] },

  deskOrLaptop: { id:"deskOrLaptop", type:"select",
    he:"נייח או נייד?", en:"Desktop or laptop?",
    options:[["מחשב נייח","Desktop"],["מחשב נייד","Laptop"],["לא בטוח","Not sure"]] },

  boots: { id:"boots", type:"select",
    he:"המחשב עולה ועובד כרגע?", en:"Does the PC currently boot and work?",
    options:[["כן, עובד","Yes, it works"],
             ["עולה אבל עם תקלות","It boots but misbehaves"],
             ["לא נדלק בכלל","It doesn't power on at all"]] },

  files: { id:"files", type:"select",
    he:"מה לגבי הקבצים האישיים?", en:"What about your personal files?",
    options:[["יש לי גיבוי — אפשר למחוק הכל","I have a backup — everything can be wiped"],
             ["אין גיבוי — חשוב לי שתשמור אותם","No backup — please preserve them"],
             ["אין שם שום דבר חשוב","There's nothing important on it"]] },

  winEdition: { id:"winEdition", type:"select",
    he:"איזו גרסה?", en:"Which edition?",
    options:[["Windows 11 Home","Windows 11 Home"],
             ["Windows 11 Pro","Windows 11 Pro"],
             ["לא משנה לי — תמליץ","No preference — recommend one"]] },

  /* ⚠️ יישוב ולא כתובת מלאה. הכתובת המדויקת נמסרת בטלפון כשקובעים,
     ואין שום סיבה שהיא תעבור דרך טופס באתר. */
  city: { id:"city", type:"text", max:60,
    he:"באיזה יישוב?", en:"Which town?",
    hintHe:"קובע את מחיר הנסיעה — לכן זו השאלה היחידה על המיקום. את הכתובת המדויקת נסגור בטלפון.",
    hintEn:"This sets the travel price — it's the only location question. We'll settle the exact address by phone.",
    phHe:"למשל: פתח תקווה", phEn:"e.g. Petah Tikva" },

  when: { id:"when", type:"select",
    he:"מתי נוח לך?", en:"When suits you?",
    options:[["בוקר","Morning"],["צהריים","Midday"],["אחר הצהריים / ערב","Afternoon / evening"],
             ["סוף שבוע","Weekend"],["גמיש","Flexible"]] },

  budget: { id:"budget", type:"select",
    he:"תקציב משוער", en:"Approximate budget",
    options:[["עד 3,000 ₪","Up to ₪3,000"],["3,000–5,000 ₪","₪3,000–5,000"],
             ["5,000–8,000 ₪","₪5,000–8,000"],["8,000–12,000 ₪","₪8,000–12,000"],
             ["מעל 12,000 ₪","Over ₪12,000"],["עוד לא יודע","Not sure yet"]] }
};

/* ==================== השירותים ==================== */
/* key + sku זהים ל-REAL_SUMIT_SKUS ב-4-payment-api.gs. */
const SUP_SERVICES = [

  /* ---------- הרכבה ---------- */
  { key:"assembly-parts", sku:"CLI-4001", cat:"assembly", price:300,
    he:"הרכבת מחשב (החלקים שלך)", en:"PC assembly (your own parts)",
    descHe:"הרכבה מלאה, סידור כבלים ובדיקת יציבות. בלי התקנת מערכת הפעלה.",
    descEn:"Full build, cable management and a stability test. OS install not included.",
    q:[ SQ.partsReady, SQ.partsList, SQ.handover ] },

  { key:"assembly-win", sku:"CLI-4002", cat:"assembly", price:400,
    he:"הרכבה + Windows + דרייברים", en:"Assembly + Windows + drivers",
    descHe:"הרכבה, התקנת Windows ודרייברים. הרישיון לא כלול במחיר.",
    descEn:"Build, Windows install and drivers. The license is not included.",
    q:[ SQ.partsReady, SQ.partsList,
        { id:"hasKey", type:"select",
          he:"יש לך כבר מפתח Windows?", en:"Do you already have a Windows key?",
          hintHe:"המחיר הזה לא כולל רישיון. אם אין לך — אפשר להוסיף אותו (ההרכבה עם רישיון עולה 550 ₪).",
          hintEn:"This price excludes the license. If you don't have one, it can be added (assembly with a license is ₪550).",
          options:[["כן, יש לי מפתח","Yes, I have a key"],
                   ["לא — אשמח שתוסיף רישיון","No — please add a license"],
                   ["לא בטוח","Not sure"]] } ] },

  { key:"assembly-win-lic", sku:"CLI-4003", cat:"assembly", price:550,
    he:"הרכבה + Windows + דרייברים + רישיון", en:"Assembly + Windows + drivers + license",
    descHe:"הכל כלול: הרכבה, מערכת הפעלה, דרייברים ורישיון Windows חוקי.",
    descEn:"All included: build, OS, drivers and a genuine Windows license.",
    q:[ SQ.partsReady, SQ.partsList, SQ.winEdition ] },

  /* ---------- מערכת הפעלה ---------- */
  { key:"win11-license", sku:"CLI-4006", cat:"os", price:300,
    he:"התקנת Windows 11 + רישיון", en:"Windows 11 install + license",
    descHe:"התקנה נקייה, דרייברים, עדכונים ורישיון חוקי.",
    descEn:"Clean install, drivers, updates and a genuine license.",
    q:[ SQ.deskOrLaptop, SQ.files, SQ.boots, SQ.winEdition ] },

  { key:"win11-own-license", sku:"CLI-4007", cat:"os", price:200,
    he:"התקנת Windows (יש לך רישיון)", en:"Windows install (you have a license)",
    descHe:"אותה התקנה, בלי עלות הרישיון.",
    descEn:"The same install, without the cost of the license.",
    q:[ SQ.deskOrLaptop,
        { id:"licenseKind", type:"select",
          he:"איזה רישיון יש לך?", en:"What kind of license do you have?",
          options:[["מפתח שקניתי","A key I purchased"],
                   ["רישיון דיגיטלי שכבר מחובר למחשב","A digital license already tied to this PC"],
                   ["רישיון של מקום העבודה / Microsoft 365","A work / Microsoft 365 license"],
                   ["לא בטוח","Not sure"]] },
        SQ.files, SQ.boots ] },

  { key:"format-reinstall", sku:"CLI-4008", cat:"os", price:350,
    he:"פירמוט + התקנה מחדש", en:"Format + clean reinstall",
    descHe:"מחיקה מלאה והתקנה מאפס, כולל דרייברים ותוכנות בסיס.",
    descEn:"Full wipe and a from-scratch install, including drivers and basic software.",
    q:[ { id:"whyFormat", type:"select",
          he:"למה מפרמטים?", en:"Why a format?",
          options:[["המחשב איטי מאוד","The PC is very slow"],
                   ["וירוס / נוזקה / פרסומות","Virus / malware / adware"],
                   ["שגיאות ותקלות חוזרות","Recurring errors and crashes"],
                   ["מחשב יד שנייה — רוצה להתחיל נקי","Second-hand PC — starting clean"],
                   ["אחר","Other"]] },
        SQ.files, SQ.deskOrLaptop, SQ.boots ] },

  /* ---------- ביקור בית ----------
     שלוש המדרגות נבדלות רק בזמן הנסיעה — נתון שהלקוח לא באמת יודע.
     לכן כל שלושתן שואלות קודם כל את היישוב, וההערה בראש הקטגוריה
     מסבירה שהמחיר הסופי מאושר לפני הקביעה. */
  { key:"visit-30", sku:"CLI-4009", cat:"visit", price:250,
    he:"ביקור בית — עד 30 דק' נסיעה", en:"Home visit — up to 30 min travel",
    q:[ SQ.city,
        { id:"visitIssue", type:"textarea", max:500,
          he:"מה צריך לעשות בביקור?", en:"What needs to be done during the visit?",
          phHe:"המחשב לא עולה / להתקין ציוד חדש / הרשת נופלת…",
          phEn:"PC won't boot / install new gear / the network keeps dropping…" },
        { id:"deviceCount", type:"select",
          he:"כמה מחשבים או מכשירים?", en:"How many computers or devices?",
          options:[["אחד","One"],["שניים","Two"],["שלושה ומעלה","Three or more"]] },
        SQ.when ] },

  { /* ⚠️ **שתי מדרגות בלבד — החלטת דביר 16.08.2026.** קודם היו שלוש
       (30 דק' / שעה / שעה וחצי) ועוד "נסיעה בלבד". נסיעה של שעה ומעלה
       אינה משתלמת — הזמן עולה יותר מהשירות — ולכן המדרגות מעל 45 דקות
       בוטלו. אין "צור קשר לאזורים רחוקים" בכוונה: הבטחה מרומזת שאולי
       כן נגיע גרועה מגבול ברור.
       ⚠️ מק"ט CLI-4010 **ממוחזר** מ-"עד שעה נסיעה" — צריך לשנות את
       השם והמחיר של אותו פריט ב-SUMIT ל-"עד 45 דק'" / 300 ₪. */
    key:"visit-45", sku:"CLI-4010", cat:"visit", price:300,
    he:"ביקור בית — עד 45 דק' נסיעה", en:"Home visit — up to 45 min travel",
    q:[ SQ.city,
        { id:"visitIssue", type:"textarea", max:500,
          he:"מה צריך לעשות בביקור?", en:"What needs to be done during the visit?",
          phHe:"המחשב לא עולה / להתקין ציוד חדש / הרשת נופלת…",
          phEn:"PC won't boot / install new gear / the network keeps dropping…" },
        { id:"deviceCount", type:"select",
          he:"כמה מחשבים או מכשירים?", en:"How many computers or devices?",
          options:[["אחד","One"],["שניים","Two"],["שלושה ומעלה","Three or more"]] },
        SQ.when ] },

  { key:"onsite-setup", sku:"CLI-4013", cat:"visit", price:400,
    he:"התקנת מחשב בעמדת הלקוח", en:"On-site PC setup",
    descHe:"מגיע, מחבר ומעמיד את העמדה לעבודה. כולל הגעה עד 30 דק' נסיעה.",
    descEn:"I come over, connect everything and get the workstation running. Includes travel of up to 30 minutes.",
    q:[ SQ.city,
        { id:"setupWhat", type:"select",
          he:"מה מתקינים?", en:"What are we setting up?",
          options:[["מחשב חדש שקניתי דרכך","A new PC I bought from you"],
                   ["מחשב חדש שקניתי במקום אחר","A new PC I bought elsewhere"],
                   ["העברה או סידור של עמדה קיימת","Moving or reorganising an existing setup"]] },
        { id:"setupExtras", type:"multi",
          he:"מה עוד בעמדה?", en:"What else is in the setup?",
          options:[["מסך אחד","One monitor"],["שני מסכים או יותר","Two monitors or more"],
                   ["מדפסת / סורק","Printer / scanner"],["חיבור לרשת ולאינטרנט","Network & internet setup"],
                   ["העברת קבצים מהמחשב הישן","Move files from the old PC"]] },
        SQ.when ] },

  /* ---------- תמיכה ---------- */
  { key:"remote-support", sku:"CLI-4014", cat:"support", price:120,
    he:"תמיכה מרחוק (שעה)", en:"Remote support (1 hour)",
    descHe:"מתחבר למחשב שלך ופותר בזמן אמת. שעת עבודה.",
    descEn:"I connect to your PC and fix things live. One working hour.",
    q:[ { id:"remoteIssue", type:"textarea", max:500,
          he:"מה הבעיה?", en:"What's the problem?",
          phHe:"תוכנה שלא נפתחת, מדפסת שלא מדפיסה, הגדרה שלא מסתדרת…",
          phEn:"An app that won't open, a printer that won't print, a setting that won't stick…" },
        /* ⚠️ השאלה החשובה כאן. בלי אינטרנט אין תמיכה מרחוק בכלל, ועדיף
           לגלות את זה עכשיו ולא אחרי שנקבע שעה. */
        { id:"hasInternet", type:"select",
          he:"המחשב מתחבר לאינטרנט?", en:"Does the PC connect to the internet?",
          hintHe:"בלי חיבור אין תמיכה מרחוק — נצטרך ביקור בית או מסירה.",
          hintEn:"Without a connection remote support isn't possible — we'd need a home visit or a drop-off.",
          options:[["כן","Yes"],["מתנתק לסירוגין","It keeps dropping"],["לא מתחבר בכלל","No connection at all"]] },
        { id:"osVersion", type:"select",
          he:"איזו מערכת הפעלה?", en:"Which operating system?",
          options:[["Windows 11","Windows 11"],["Windows 10","Windows 10"],
                   ["אחר","Other"],["לא יודע","Not sure"]] },
        SQ.when ] },

  /* השירות המרכזי בדף — כאן השאלות הן בדיוק מה שטכנאי שואל בטלפון. */
  { key:"diagnostics", sku:"CLI-4015", cat:"support", price:150,
    he:"אבחון תקלה", en:"Fault diagnosis",
    descHe:"בודק מה באמת התקלה ואומר לך מה צריך — לפני שמחליפים חלקים.",
    descEn:"I find out what's actually wrong and tell you what it needs — before anything gets replaced.",
    q:[ { id:"whatHappens", type:"textarea", max:600,
          he:"מה קורה?", en:"What's happening?",
          phHe:"תאר במילים שלך: מתי זה קורה, מה רואים על המסך, יש רעש או ריח…",
          phEn:"In your own words: when it happens, what's on the screen, any noise or smell…" },
        { id:"powersOn", type:"select",
          he:"המחשב נדלק בכלל?", en:"Does the PC power on at all?",
          options:[["נדלק ועובד","Powers on and works"],
                   ["נדלק אבל אין תמונה","Powers on but no display"],
                   ["מאווררים מסתובבים ומיד נכבה","Fans spin then it shuts off"],
                   ["נכבה מעצמו תוך כדי עבודה","Shuts down by itself while in use"],
                   ["לא נדלק בכלל","Doesn't power on at all"]] },
        { id:"since", type:"select",
          he:"מתי זה התחיל?", en:"When did it start?",
          options:[["היום","Today"],["השבוע","This week"],
                   ["לפני יותר מחודש","More than a month ago"],["תמיד היה ככה","It's always been like this"]] },
        { id:"changed", type:"select",
          he:"משהו השתנה לפני שזה התחיל?", en:"Did anything change right before it started?",
          options:[["הוספתי או החלפתי חומרה","I added or replaced hardware"],
                   ["עדכון Windows","A Windows update"],
                   ["התקנתי תוכנה או משחק","I installed software or a game"],
                   ["הפסקת חשמל או נפילת מתח","A power cut or surge"],
                   ["הזזתי או ניקיתי את המחשב","I moved or cleaned the PC"],
                   ["לא, כלום","No, nothing"]] },
        SQ.deskOrLaptop ] },

  /* ⚠️ 300 ולא 450. הלקוח שכבר יודע שהוא רוצה שאתקן בוחר כאן ישירות,
     והאבחון נבלע במחיר — בלי הכרטיס הזה הוא היה בוחר "אבחון" ואז
     "תיקון" ומשלם 150+300 על אותה עבודה. אותה טעות בדיוק שהיתה
     בחבילת "הכל כלול". המחיר חייב להישאר זהה ל-PRICE_LIST ב-
     2-pricelist-picker.gs ול-REAL_SUMIT_SKUS ב-4-payment-api.gs. */
  { key:"diagnose-repair", sku:"CLI-4023", cat:"support", price:300,
    he:"אבחון + תיקון תקלה", en:"Diagnosis + repair",
    descHe:"כולל את האבחון — לא משלמים עליו פעמיים. אם התיקון דורש חלק חדש, אומר לך את המחיר לפני שמזמינים.",
    descEn:"The diagnosis is included — you don't pay for it twice. If the repair needs a new part, I'll quote it before ordering.",
    q:[ { id:"whatHappens", type:"textarea", max:600,
          he:"מה קורה?", en:"What's happening?",
          phHe:"תאר במילים שלך: מתי זה קורה, מה רואים על המסך, יש רעש או ריח…",
          phEn:"In your own words: when it happens, what's on the screen, any noise or smell…" },
        { id:"powersOn", type:"select",
          he:"המחשב נדלק בכלל?", en:"Does the PC power on at all?",
          options:[["נדלק ועובד","Powers on and works"],
                   ["נדלק אבל אין תמונה","Powers on but no display"],
                   ["מאווררים מסתובבים ומיד נכבה","Fans spin then it shuts off"],
                   ["נכבה מעצמו תוך כדי עבודה","Shuts down by itself while in use"],
                   ["לא נדלק בכלל","Doesn't power on at all"]] },
        { id:"knownPart", type:"select",
          he:"אתה כבר יודע מה תקול?", en:"Do you already know what's faulty?",
          options:[["לא — בשביל זה אני פונה","No — that's why I'm asking"],
                   ["יש לי ניחוש","I have a guess"],
                   ["כן, מישהו כבר אבחן","Yes, someone already diagnosed it"]] },
        SQ.deskOrLaptop,
        SQ.handover ] },

  /* ⚠️ המחיר 80 ₪ **אושר על ידי דביר** (16.08.2026) — הוא הועלה ל-100
     בטיוטה ואז הורד. חייב להישאר זהה לשלושת המקומות האחרים:
     PRICE_LIST ב-2-pricelist-picker.gs · DVT_SERVICES ב-checkout.js ·
     SERVICE_OPTIONS_ ב-4-payment-api.gs. שינוי באחד בלי השאר =
     הלקוח רואה מחיר אחד ומשלם אחר.
     ⚠️ מק"ט CLI-4024 **עדיין לא נוצר ב-SUMIT.** כאן זו פנייה בוואטסאפ
     בלבד ולכן אין סיכון, אבל בקופה השורה תיפול עד שהמק"ט ייווצר. */
  { key:"software-install", sku:"CLI-4024", cat:"support", price:80,
    he:"התקנת תוכנות", en:"Software installation",
    descHe:"מתקין ומגדיר את מה שאתה צריך — אופיס, דרייברים, אנטי-וירוס, תוכנות עבודה.",
    descEn:"I install and set up what you need — Office, drivers, antivirus, work software.",
    q:[ { id:"whatSoftware", type:"textarea", max:400,
          he:"אילו תוכנות?", en:"Which software?",
          phHe:"אופיס, כרום, אנטי-וירוס, תוכנת עריכה…",
          phEn:"Office, Chrome, antivirus, an editing suite…" },
        /* ⚠️ שאלת הרישיונות היא לא פורמליות: דביר אינו מספק רישיונות
           לתוכנות צד שלישי, וההנחה השגויה הזו מתגלה בדרך כלל רק כשהוא
           כבר מול המחשב. עדיף לברר את זה בפנייה. */
        { id:"hasLicenses", type:"select",
          he:"יש לך רישיונות לתוכנות האלה?", en:"Do you have licenses for them?",
          hintHe:"רישיונות בתשלום אינם כלולים במחיר השירות.",
          hintEn:"Paid licenses are not included in the service price.",
          options:[["כן, יש לי","Yes, I have them"],
                   ["רק לחלק","For some of them"],
                   ["לא — צריך ייעוץ","No — I need advice"],
                   ["רק תוכנות חינמיות","Free software only"]] },
        SQ.deskOrLaptop,
        SQ.handover ] },

  { key:"pre-buy-advice", sku:"CLI-4016", cat:"support", price:0,
    he:"ייעוץ לפני קנייה", en:"Pre-purchase advice",
    descHe:"אומר לך מה באמת צריך בשביל מה שאתה עושה — ומה מיותר.",
    descEn:"I tell you what you actually need for what you do — and what's a waste.",
    q:[ { id:"purpose", type:"select",
          he:"למה המחשב?", en:"What's the PC for?",
          options:[["גיימינג","Gaming"],["עריכת וידאו / גרפיקה","Video / graphics editing"],
                   ["עבודה ומשרד","Work & office"],["לימודים","Studies"],
                   ["שרת / תחנת עבודה","Server / workstation"],["שימוש כללי","General use"]] },
        SQ.budget,
        { id:"reuse", type:"multi",
          he:"יש משהו קיים שאפשר לשמור?", en:"Anything you already own that we can keep?",
          options:[["מסך","Monitor"],["מקלדת ועכבר","Keyboard & mouse"],["מארז","Case"],
                   ["דיסקים","Drives"],["לא — הכל חדש","Nothing — all new"]] },
        { id:"mustHave", type:"textarea", opt:true, max:300,
          he:"משהו שחשוב לך במיוחד? (לא חובה)", en:"Anything that matters to you in particular? (optional)",
          phHe:"שקט, גודל קטן, תאורה, אפשרות לשדרג בעתיד…",
          phEn:"Quiet, small footprint, RGB, room to upgrade later…" } ] },

  /* ---------- תיקונים ---------- */
  { key:"part-upgrade", sku:"CLI-4017", cat:"repairs", price:150,
    he:"שדרוג רכיב (התקנה בלבד)", en:"Component upgrade (installation only)",
    descHe:"התקנה והרצה של הרכיב. מחיר הרכיב עצמו לא כלול.",
    descEn:"Installing and running in the component. The part itself is not included.",
    q:[ { id:"whichPart", type:"multi",
          he:"איזה רכיב?", en:"Which component?",
          options:[["כרטיס מסך","Graphics card"],["מעבד","CPU"],["זיכרון RAM","RAM"],
                   ["דיסק SSD / NVMe","SSD / NVMe drive"],["ספק כוח","Power supply"],
                   ["קירור","Cooling"],["מארז","Case"],["אחר","Other"]] },
        { id:"hasPart", type:"select",
          he:"החלק כבר אצלך?", en:"Do you already have the part?",
          options:[["כן, קניתי אותו","Yes, I bought it"],
                   ["לא — אשמח שתזמין בשבילי","No — please order it for me"],
                   ["עוד לא החלטתי מה לקנות","I haven't decided what to buy"]] },
        { id:"currentPc", type:"textarea", max:400,
          he:"מה המחשב שיש לך היום?", en:"What PC do you have today?",
          hintHe:"דגם או הרכיבים העיקריים — כדי לוודא שהשדרוג בכלל מתאים לו.",
          hintEn:"Model or the main components — so I can confirm the upgrade actually fits.",
          phHe:"למשל: מעבד i5-12400, לוח B660, ספק 550W",
          phEn:"e.g. i5-12400 CPU, B660 board, 550W PSU" },
        SQ.deskOrLaptop ] },

  { key:"clean-thermal", sku:"CLI-4018", cat:"repairs", price:150,
    he:"ניקוי פנימי + משחה תרמית", en:"Internal cleaning + thermal paste",
    descHe:"פירוק, ניקוי אבק והחלפת משחה תרמית. מוריד חום ורעש.",
    descEn:"Teardown, dust removal and fresh thermal paste. Lower temps and less noise.",
    q:[ SQ.deskOrLaptop,
        { id:"symptom", type:"select",
          he:"מה מרגישים?", en:"What are you noticing?",
          options:[["מתחמם ומאט","It gets hot and slows down"],
                   ["המאווררים רועשים","The fans are loud"],
                   ["נכבה מעצמו","It shuts down by itself"],
                   ["הכל בסדר — תחזוקה תקופתית","Nothing wrong — routine maintenance"]] },
        { id:"lastClean", type:"select",
          he:"מתי ניקו לאחרונה?", en:"When was it last cleaned?",
          options:[["אף פעם","Never"],["לפני יותר משנה","Over a year ago"],
                   ["בשנה האחרונה","Within the past year"],["לא יודע","Not sure"]] } ] },

  { key:"data-transfer", sku:"CLI-4019", cat:"repairs", price:200,
    he:"העברת נתונים / גיבוי", en:"Data transfer / backup",
    descHe:"מעביר קבצים, תמונות ומיילים — גם ממחשב שכבר לא עולה.",
    descEn:"Moving files, photos and mail — including off a PC that no longer boots.",
    q:[ { id:"fromWhere", type:"select",
          he:"מאיפה מעבירים?", en:"Transfer from where?",
          options:[["מחשב ישן שעובד","An old PC that still works"],
                   ["מחשב שלא נדלק","A PC that won't power on"],
                   ["דיסק חיצוני / דיסק שלוף","External or removed drive"],
                   ["טלפון","A phone"],["לא בטוח","Not sure"]] },
        { id:"toWhere", type:"select",
          he:"לאן?", en:"Transfer to where?",
          options:[["מחשב חדש","A new PC"],["דיסק חיצוני","An external drive"],
                   ["ענן","Cloud storage"],["עוד לא יודע","Not sure yet"]] },
        { id:"volume", type:"select",
          he:"כמה נפח בערך?", en:"Roughly how much data?",
          options:[["עד 100GB","Up to 100GB"],["100GB–500GB","100GB–500GB"],
                   ["500GB–1TB","500GB–1TB"],["מעל 1TB","Over 1TB"],["לא יודע","Not sure"]] } ] },

  /* ---------- חבילות ---------- */
  { key:"bundle-new-pc", sku:"CLI-4020", cat:"bundles", price:700,
    he:"חבילה: מחשב חדש — הכל כלול", en:"Bundle: new PC — everything included",
    descHe:"הרכבה + Windows + רישיון + התקנה אצלך. הכל בפגישה אחת.",
    descEn:"Assembly + Windows + license + setup at your place. All in one go.",
    q:[ { id:"partsSource", type:"select",
          he:"מאיפה החלקים?", en:"Where are the parts coming from?",
          options:[["בניתי בבונה המחשבים באתר","I built it in the site's PC builder"],
                   ["קניתי חלקים בעצמי","I bought the parts myself"],
                   ["אשמח שתרכיב ותזמין הכל בשבילי","I'd like you to spec and order everything"]] },
        { id:"bundleSpec", type:"textarea", opt:true, max:400,
          he:"מה החלקים או מה התקציב? (לא חובה)", en:"Which parts, or what budget? (optional)",
          phHe:"רשימת חלקים אם יש, או תקציב משוער",
          phEn:"A parts list if you have one, or an approximate budget" },
        { id:"needsOnsite", type:"select",
          he:"צריך גם התקנה אצלך בבית?", en:"Do you also need setup at your place?",
          options:[["כן","Yes"],["לא — אאסוף בעצמי","No — I'll pick it up"]] },
        { id:"needsTransfer", type:"select",
          he:"להעביר נתונים ממחשב ישן?", en:"Move data from an old PC?",
          options:[["כן","Yes"],["לא","No"],["אין לי מחשב ישן","I don't have an old PC"]] } ] },

  { key:"bundle-upgrade", sku:"CLI-4021", cat:"bundles", price:350,
    he:"חבילה: שדרוג מלא", en:"Bundle: full upgrade",
    descHe:"בודק מה שווה לשדרג במחשב הקיים, מתקין ומריץ.",
    descEn:"I work out what's worth upgrading in your current PC, then install and run it in.",
    q:[ { id:"currentPc", type:"textarea", max:400,
          he:"מה המחשב שיש לך היום?", en:"What PC do you have today?",
          phHe:"דגם או הרכיבים העיקריים, ואם ידוע — גיל המחשב",
          phEn:"Model or the main components, and its age if you know it" },
        { id:"painPoint", type:"select",
          he:"מה הכי מפריע?", en:"What bothers you most?",
          options:[["איטי בהכל","Slow at everything"],["משחקים לא רצים חלק","Games don't run smoothly"],
                   ["נגמר מקום אחסון","Out of storage space"],["רועש ומתחמם","Loud and hot"],
                   ["אחר","Other"]] },
        { id:"hasParts", type:"select",
          he:"יש לך כבר חלקים לשדרוג?", en:"Do you already have upgrade parts?",
          options:[["כן","Yes"],["לא — אשמח להמלצה","No — I'd like a recommendation"]] },
        SQ.budget ] },

  { key:"bundle-yearly", sku:"CLI-4022", cat:"bundles", price:600,
    he:"חבילת ליווי שנתית", en:"Annual support plan",
    descHe:"זמין לך לאורך השנה — תקלות, תחזוקה וייעוץ, בלי לספור שיחות.",
    descEn:"Available to you all year — faults, maintenance and advice, without counting calls.",
    q:[ { id:"machines", type:"select",
          he:"כמה מחשבים בליווי?", en:"How many computers in the plan?",
          options:[["אחד","One"],["שניים","Two"],["שלושה עד חמישה","Three to five"],
                   ["יותר מחמישה","More than five"]] },
        { id:"homeOrBiz", type:"select",
          he:"בית או עסק?", en:"Home or business?",
          options:[["בית","Home"],["עסק קטן","Small business"]] },
        { id:"planFocus", type:"multi",
          he:"מה הכי חשוב לך?", en:"What matters most to you?",
          options:[["זמינות מהירה כשיש תקלה","Fast response when something breaks"],
                   ["תחזוקה תקופתית","Routine maintenance"],
                   ["גיבויים","Backups"],
                   ["ייעוץ ורכש","Advice & purchasing"]] } ] }
];

/* ==================== מצב ==================== */
/* ⚠️ הבחירה היא **רשימה** ולא מפתח בודד, וזה כל השינוי המהותי בדף.
   לקוח שצריך גם ניקוי פנימי וגם שדרוג רכיב לא אמור לשלוח שתי פניות
   נפרדות ולא אמור לבחור אחד ולוותר על השני. הסדר נשמר לפי סדר הסימון
   כדי שההודעה תצא באותו סדר שבו הלקוח חשב עליה.

   supAnswers חי מעבר לרינדור מחדש של הלוח (וגם אחרי ביטול סימון), כך
   ששירות שהוסר ואז הוחזר חוזר עם התשובות שכבר נכתבו בו. */
let supPicked = [];
const supAnswers = Object.create(null);            /* "svcKey|qid" -> string | string[] */
const supContactState = { name:"", phone:"", email:"" };
let supPanelSeen = false;                          /* האם לוח הפנייה במסך */
let supSpyObs = null;

function supSvc(key){ return SUP_SERVICES.find(s => s.key === key) || null; }
function supName(s){ return supTr(s.he, s.en); }
function supPriceLabel(p){
  return p === 0 ? supTr("חינם","Free") : p.toLocaleString() + " ₪";
}
function supAnsKey(key, qid){ return key + "|" + qid; }
/* התווית להודעה — בלי הסיומת "(לא חובה)" שנועדה למסך בלבד. */
function supQLabel(q){ return supTr(q.he, q.en).replace(/\s*\(לא חובה\)|\s*\(optional\)/g, ""); }
function supCountLabel(n){
  if(n === 1) return supTr("שירות אחד","1 service");
  return supTr(n + " שירותים", n + " services");
}
/* האייקון מגיע מ-sprite.js (#ui-wa) שנטען לפני הקובץ הזה. שם המחלקה
   *לא* מכיל "ui-" בכוונה: הכלל הגלובלי [class*="ui-"] use{fill:none}
   ב-style.css היה מוחק את הצורה הממולאת הזו. */
function supWaIcon(){
  return `<svg class="sup-wa-ic" viewBox="0 0 24 24" aria-hidden="true"><use href="#ui-wa"></use></svg>`;
}

/* ==================== רינדור הקטלוג ==================== */
function supRenderCats(){
  const nav = document.getElementById("supCats");
  if(!nav) return;
  nav.setAttribute("aria-label", supTr("קטגוריות שירות","Service categories"));
  nav.innerHTML = SUP_CATS.map(c => {
    const n = SUP_SERVICES.filter(s => s.cat === c.key).length;
    return `<button type="button" class="sup-chip" data-jump="supcat-${supEsc(c.key)}" data-cat="${supEsc(c.key)}">
        <span>${supEsc(supTr(c.he, c.en))}</span>
        <span class="sup-chip-n" data-n="${n}">${n}</span>
      </button>`;
  }).join("");
}

/* המונה על הצ'יפ מתחלף בין "כמה יש" ל"כמה סימנת" — כך רואים מרצועת
   הקטגוריות לבד שנשארה בחירה בקטגוריה שכבר גללנו ממנה. */
function supSyncCatBadges(){
  document.querySelectorAll(".sup-chip").forEach(chip => {
    const cat = chip.dataset.cat;
    const badge = chip.querySelector(".sup-chip-n, .sup-chip-on");
    if(!badge) return;
    const on = SUP_SERVICES.filter(s => s.cat === cat && supPicked.indexOf(s.key) !== -1).length;
    badge.className = on ? "sup-chip-on" : "sup-chip-n";
    badge.textContent = on ? String(on) : badge.dataset.n;
  });
}

function supRenderCatalog(){
  const host = document.getElementById("supCatalog");
  if(!host) return;

  host.innerHTML = SUP_CATS.map(c => {
    const list = SUP_SERVICES.filter(s => s.cat === c.key);
    if(!list.length) return "";
    const note = c.noteHe
      ? `<p class="sup-note">${supEsc(supTr(c.noteHe, c.noteEn))}</p>` : "";
    return `
      <section class="sup-sec" id="supcat-${supEsc(c.key)}">
        <h2 class="sup-sec-h">
          <span>${supEsc(supTr(c.he, c.en))}</span>
          <span class="sup-sec-c">${supEsc(supCountLabel(list.length))}</span>
        </h2>
        ${note}
        <div class="sup-grid">
          ${list.map(supCardHtml).join("")}
        </div>
      </section>`;
  }).join("");
}

/* ⚠️ בכרטיס יש שתי פעולות נפרדות ולכן שני משטחים נפרדים:
     • ה-<label> העליון מסמן/מבטל — צ'קבוקס אמיתי, כך שהמקלדת עובדת
       לבד ואין צורך ב-role="button" ידני כמו בגרסה הקודמת.
     • כפתור הוואטסאפ בפס התחתון שולח *רק* את השירות הזה, מיד.
   שתי הפעולות לא יכולות להתחלף בטעות כי הן לא חולקות אותו שטח לחיץ. */
function supCardHtml(s){
  const on = supPicked.indexOf(s.key) !== -1;
  const desc = s.descHe
    ? `<span class="sup-card-d">${supEsc(supTr(s.descHe, s.descEn))}</span>` : "";
  const qn = (s.q && s.q.length)
    ? supTr(s.q.length + " שאלות קצרות", s.q.length + " quick questions")
    : supTr("בלי שאלות","No questions");
  const aria = supTr("הוספה לפנייה: ","Add to request: ") + supName(s) + " — " + supPriceLabel(s.price);

  return `
    <article class="sup-card${on ? " is-on" : ""}"
             data-key="${supEsc(s.key)}" data-sku="${supEsc(s.sku)}" data-price="${s.price}">
      <label class="sup-pick">
        <input type="checkbox" class="sup-tick" data-pick="${supEsc(s.key)}"
               aria-label="${supEsc(aria)}"${on ? " checked" : ""}>
        <span class="sup-box" aria-hidden="true"></span>
        <span class="sup-head">
          <span class="sup-card-t">${supEsc(supName(s))}</span>
          <span class="sup-price${s.price === 0 ? " is-free" : ""}">${supEsc(supPriceLabel(s.price))}</span>
        </span>
        ${desc}
      </label>
      <div class="sup-card-f">
        <span class="sup-qn">${supEsc(qn)}</span>
        <button type="button" class="sup-wa" data-quick="${supEsc(s.key)}">
          ${supWaIcon()}<span>${supEsc(supTr("פנייה בוואטסאפ","Ask on WhatsApp"))}</span>
        </button>
      </div>
    </article>`;
}

function supSyncCards(){
  document.querySelectorAll(".sup-card").forEach(card => {
    const on = supPicked.indexOf(card.dataset.key) !== -1;
    card.classList.toggle("is-on", on);
    const cb = card.querySelector(".sup-tick");
    if(cb && cb.checked !== on) cb.checked = on;
  });
}

/* ==================== רינדור לוח הפנייה ==================== */
function supCtrlHtml(s, q, id){
  const saved = supAnswers[supAnsKey(s.key, q.id)];
  const arr   = Array.isArray(saved) ? saved : [];
  const str   = Array.isArray(saved) ? "" : String(saved == null ? "" : saved);
  const meta  = `id="${id}" data-ans="${supEsc(supAnsKey(s.key, q.id))}" data-qtype="${supEsc(q.type || "text")}"`;
  const ph    = supEsc(q.phHe ? supTr(q.phHe, q.phEn) : "");

  if(q.type === "select"){
    return `<select class="sup-in" ${meta}>
        <option value="">${supEsc(supTr("בחר…","Choose…"))}</option>
        ${q.options.map(o => {
          const v = supTr(o[0], o[1]);
          return `<option value="${supEsc(v)}"${v === str ? " selected" : ""}>${supEsc(v)}</option>`;
        }).join("")}
      </select>`;
  }
  if(q.type === "textarea"){
    return `<textarea class="sup-in sup-ta" ${meta} rows="3" maxlength="${q.max || 500}"
        placeholder="${ph}">${supEsc(str)}</textarea>`;
  }
  if(q.type === "multi"){
    return `<div class="sup-opts" ${meta}>
        ${q.options.map(o => {
          const v = supTr(o[0], o[1]);
          return `<label class="sup-opt"><input type="checkbox" value="${supEsc(v)}"${
            arr.indexOf(v) !== -1 ? " checked" : ""}><span>${supEsc(v)}</span></label>`;
        }).join("")}
      </div>`;
  }
  return `<input class="sup-in" type="text" ${meta} maxlength="${q.max || 120}"
      value="${supEsc(str)}" placeholder="${ph}">`;
}

function supQuestionHtml(s, q, idx, strict){
  const id    = "q_" + s.key + "_" + q.id;
  const hint  = q.hintHe ? `<p class="sup-hint">${supEsc(supTr(q.hintHe, q.hintEn))}</p>` : "";
  const req   = (!q.opt && strict) ? ` <span class="sup-req" aria-hidden="true">*</span>` : "";
  return `<div class="sup-q">
      <label class="field-label" for="${id}">${idx + 1}. ${supEsc(supTr(q.he, q.en))}${req}</label>
      ${hint}
      ${supCtrlHtml(s, q, id)}
    </div>`;
}

function supItemHtml(s, strict){
  const qs = s.q || [];
  const qHtml = qs.length ? `
      <details class="sup-item-q"${strict ? " open" : ""}>
        <summary>${supEsc(strict
          ? supTr("כמה פרטים שיעזרו לי להגיע מוכן","A few details so I arrive prepared")
          : supTr("פרטים על השירות הזה (לא חובה)","Details for this service (optional)"))}</summary>
        <div class="sup-item-qs">${qs.map((q, i) => supQuestionHtml(s, q, i, strict)).join("")}</div>
      </details>` : "";

  return `
    <div class="sup-item" data-item="${supEsc(s.key)}">
      <div class="sup-item-h">
        <span class="sup-plus" aria-hidden="true">+</span>
        <span class="sup-item-n">${supEsc(supName(s))}</span>
        <span class="sup-item-p">${supEsc(supPriceLabel(s.price))}</span>
        <button type="button" class="sup-item-x" data-drop="${supEsc(s.key)}"
                aria-label="${supEsc(supTr("הסרה מהפנייה: ","Remove from request: ") + supName(s))}">✕</button>
      </div>
      ${qHtml}
    </div>`;
}

function supRenderPanel(){
  const box = document.getElementById("supPanel");
  if(!box) return;

  const services = supPicked.map(supSvc).filter(Boolean);
  const n = services.length;
  /* ⚠️ שירות אחד = פנייה ממוקדת, ולכן השאלות שלו נשארות חובה בדיוק כמו
     בגרסה הקודמת. שניים ומעלה = רשימת רצונות, ואז 4 שאלות כפול 5
     שירותים הן בדיוק הקיר שדביר התלונן עליו — לכן הן הופכות לרשות
     והבלוקים נסגרים. הכלל נאמר במפורש על המסך כדי שלא יהיה קסם. */
  /* ⚠️ **תמיד חובה — החלטת דביר, 16.08.2026.** בגרסה הקודמת שאלות
     החובה התרככו כשנבחר יותר משירות אחד, כדי להוריד נטישה. דביר העדיף
     את הצד השני של הטרייד-אוף במפורש: "אני צריך לקבל כמה שיותר מידע,
     זה או שם או בטלפון, עדיף שיהיה שם ואני אתקשר וארחיב".
     כלומר השיחה אינה מוחלפת — היא נעשית מוכנה. `strict` נשאר כפרמטר
     ולא נמחק, כדי שאפשר יהיה לרכך שוב בשורה אחת אם הנטישה תתברר
     כבעיה אמיתית ולא משוערת. */
  const strict = true;
  void n;

  const head = `
    <div class="sup-panel-head">
      <div>
        <p class="sup-kicker">${supEsc(supTr("שלב אחרון","Last step"))}</p>
        <h2 class="sup-panel-t">${supEsc(supTr("הפנייה שלך","Your request"))}</h2>
      </div>
      <div class="sup-panel-meta">
        <span class="sup-count">${supEsc(n ? supCountLabel(n) : supTr("לא נבחר שירות","No service picked"))}</span>
        ${n ? `<button type="button" class="sup-clear" id="supClear">${supEsc(supTr("ניקוי","Clear"))}</button>` : ""}
      </div>
    </div>`;

  const tail = `
    <div class="validation-msg" id="supValidation" role="alert" style="display:none"></div>
    <p class="sup-fallback" id="supFallback" hidden></p>`;

  if(!n){
    box.innerHTML = head + `
      <p class="sup-empty">${supEsc(supTr(
        "עוד לא סימנת שירות. אפשר לסמן ✓ על כמה שירותים שרוצים ולשלוח הכל בהודעה אחת, או ללחוץ “פנייה בוואטסאפ” על כרטיס בודד ולשלוח רק אותו.",
        "Nothing ticked yet. Tick ✓ as many services as you need and send them in one message, or press “Ask on WhatsApp” on a single card to send just that one."))}</p>` + tail;
    return;
  }

  const multiNote = strict ? "" : `<p class="sup-note">${supEsc(supTr(
    "בחרת כמה שירותים, ולכן השאלות בכל שירות אינן חובה — ענה על מה שנוח, ואת השאר נשלים בשיחה.",
    "You picked several services, so the questions under each one are optional — answer what's easy and we'll cover the rest by phone."))}</p>`;

  box.innerHTML = head + `
    <div class="sup-picked">${services.map(s => supItemHtml(s, strict)).join("")}</div>
    ${multiNote}

    <div class="sup-contact">
      <h3 class="sup-sub-h">${supEsc(supTr("איך אחזור אליך?","How do I get back to you?"))}</h3>
      <p class="sup-sub-note">${supEsc(supTr(
        "שם וטלפון בלבד. הפרטים נוסעים בתוך ההודעה עצמה ולא נשמרים באתר.",
        "Name and phone only. They travel inside the message itself and are never stored on the site."))}</p>
      <div class="sup-fields">
        <div class="sup-q">
          <label class="field-label" for="supCName">${supEsc(supTr("שם","Name"))} <span class="sup-req" aria-hidden="true">*</span></label>
          <input class="sup-in" type="text" id="supCName" autocomplete="name" maxlength="60" value="${supEsc(supContactState.name)}">
        </div>
        <div class="sup-q">
          <label class="field-label" for="supCPhone">${supEsc(supTr("טלפון","Phone"))} <span class="sup-req" aria-hidden="true">*</span></label>
          <input class="sup-in" type="tel" id="supCPhone" autocomplete="tel" dir="ltr" maxlength="20"
                 placeholder="050-0000000" value="${supEsc(supContactState.phone)}">
        </div>
        <div class="sup-q is-wide">
          <label class="field-label" for="supCEmail">${supEsc(supTr("אימייל (לא חובה)","Email (optional)"))}</label>
          <input class="sup-in" type="email" id="supCEmail" autocomplete="email" dir="ltr" maxlength="80" value="${supEsc(supContactState.email)}">
        </div>
      </div>
    </div>

    <details class="sup-preview">
      <summary>${supEsc(supTr("תצוגה מקדימה של ההודעה","Preview the message"))}</summary>
      <pre class="sup-pre" id="supPreview"></pre>
    </details>
    ${tail}
    <button type="button" class="btn btn-accent" id="supSendBtn">
      ${supWaIcon()}<span>${supEsc(supTr("שליחת הפנייה בוואטסאפ","Send the request on WhatsApp"))}</span>
      <small>· ${supEsc(supCountLabel(n))}</small>
    </button>
    <p class="sup-send-note">${supEsc(supTr(
      "הכפתור פותח וואטסאפ עם ההודעה מוכנה — רק ללחוץ שליחה. שום דבר לא נרכש כאן: נסגור ביחד לפני שמתחילים.",
      "The button opens WhatsApp with the message ready — just hit send. Nothing is purchased here: we'll agree on it together before starting."))}</p>`;

  supUpdatePreview();
}

/* ==================== קליטת תשובות ==================== */
/* נקראת לפני כל רינדור מחדש של הלוח, כך שסימון שירות נוסף באמצע
   מילוי טופס לא מוחק את מה שכבר נכתב. */
function supCapture(){
  document.querySelectorAll("#supPanel [data-ans]").forEach(el => {
    const k = el.dataset.ans;
    if(el.dataset.qtype === "multi"){
      supAnswers[k] = Array.prototype.slice.call(el.querySelectorAll("input:checked")).map(i => i.value);
    } else {
      supAnswers[k] = el.value;
    }
  });
  const g = id => { const e = document.getElementById(id); return e ? e.value : null; };
  const nm = g("supCName"), ph = g("supCPhone"), em = g("supCEmail");
  if(nm !== null) supContactState.name  = nm;
  if(ph !== null) supContactState.phone = ph;
  if(em !== null) supContactState.email = em;
}

/* ⚠️ תשובות של select/multi הן מחרוזות בשפה שבה נבחרו. במעבר שפה הן
   כבר לא תואמות לאף אפשרות ברשימה החדשה, והיו יוצאות בעברית בתוך
   הודעה באנגלית. טקסט חופשי נשאר — הוא נכתב בידי הלקוח. */
function supDropLocalizedAnswers(){
  SUP_SERVICES.forEach(s => (s.q || []).forEach(q => {
    if(q.type === "select" || q.type === "multi") delete supAnswers[supAnsKey(s.key, q.id)];
  }));
}

function supItemFor(s){
  const answers = [];
  (s.q || []).forEach(q => {
    const raw = supAnswers[supAnsKey(s.key, q.id)];
    const val = Array.isArray(raw) ? raw.join(", ") : String(raw == null ? "" : raw).trim();
    if(val) answers.push({ q: supQLabel(q), a: val });
  });
  return { s: s, answers: answers };
}

function supNormPhone(raw){
  let p = String(raw || "").replace(/[\s\-()]/g, "");
  if(p.indexOf("+972") === 0) p = "0" + p.slice(4);
  else if(p.indexOf("972") === 0 && p.length > 10) p = "0" + p.slice(3);
  return p;
}

function supShowError(msg){
  const box = document.getElementById("supValidation");
  if(!box) return;
  box.textContent = msg;
  box.style.display = "block";
  box.scrollIntoView({ behavior:"smooth", block:"center" });
}
function supHideError(){
  const box = document.getElementById("supValidation");
  if(box) box.style.display = "none";
}

/* ==================== בניית ההודעה ==================== */
/* ⚠️ הפורמט הוא הדרישה עצמה, לא קישוט. שירות אחד = שורה אחת שמתחילה
   ב-"+", והתשובות שלו בשורות משלהן מתחתיו. בלי זה חמישה שירותים היו
   נדחסים לשורה אחת ארוכה שאי אפשר לקרוא בטלפון.
   ⚠️ אין כאן סכום. הדף אינו עגלה והשירותים אינם נרכשים בו, וסכום
   בתחתית ההודעה היה הופך פנייה להזמנה מאושרת. */
const SUP_SUBLINE = "   • ";

function supBuildMessage(items, c){
  const L = [];
  L.push(items.length === 1
    ? supTr("היי דביר, אשמח לפנות בנושא השירות הבא:",
            "Hi Dvir, I'd like to ask about the following service:")
    : supTr("היי דביר, אני מעוניין בשירותים הבאים:",
            "Hi Dvir, I'm interested in the following services:"));

  items.forEach(it => {
    L.push("+ " + supName(it.s) + " — " + supPriceLabel(it.s.price));
    it.answers.forEach(a => L.push(SUP_SUBLINE + a.q + " — " + a.a));
  });

  const who = [];
  if(c.name)  who.push(supTr("שם","Name") + ": " + c.name);
  if(c.phone) who.push(supTr("טלפון","Phone") + ": " + c.phone);
  if(c.email) who.push(supTr("אימייל","Email") + ": " + c.email);
  if(who.length){ L.push(""); who.forEach(x => L.push(x)); }

  L.push("");
  L.push(supTr("(נשלח מדף השירות באתר · מק\"ט: ", "(sent from the site's service page · SKU: ")
         + items.map(it => it.s.sku).join(", ") + ")");
  return L.join("\n");
}

function supUpdatePreview(){
  const pre = document.getElementById("supPreview");
  if(!pre) return;
  const items = supPicked.map(supSvc).filter(Boolean).map(supItemFor);
  pre.textContent = items.length ? supBuildMessage(items, supContactForMessage()) : "";
}

function supContactForMessage(){
  const name  = String(supContactState.name || "").trim();
  const phone = supNormPhone(supContactState.phone);
  const email = String(supContactState.email || "").trim();
  return {
    name : name.length >= 2 ? name : "",
    phone: /^0\d{8,9}$/.test(phone) ? phone : "",
    email: email
  };
}

/* ==================== שליחה ==================== */
function supOpenWa(msg){
  const url = `https://wa.me/${SUP_WHATSAPP_NUMBER}?text=${encodeURIComponent(msg)}`;
  const w = window.open(url, "_blank", "noopener");
  /* חוסם פופ-אפים במובייל הוא מציאות. במקום לאבד את הפנייה — קישור גלוי. */
  if(!w){
    const fb = document.getElementById("supFallback");
    if(fb){
      fb.hidden = false;
      fb.innerHTML = `<a href="${supEsc(url)}" target="_blank" rel="noopener">${
        supEsc(supTr("הדפדפן חסם את החלון — לחץ כאן לפתיחת וואטסאפ",
                     "Your browser blocked the window — tap here to open WhatsApp"))
      }</a>`;
      fb.scrollIntoView({ behavior:"smooth", block:"center" });
    }
  }
  return url;
}

/* פנייה מהירה מכרטיס בודד. אין כאן ולידציה בכוונה: מספר הטלפון של
   הלקוח מגיע לדביר ממילא יחד עם הודעת הוואטסאפ, ולכן לחסום את הכפתור
   עד שימלא טופס זה לאבד פנייה בלי שום תמורה. פרטים שכבר מולאו בלוח
   הפנייה כן נכנסים להודעה. */
function supQuickSend(key){
  const s = supSvc(key);
  if(!s) return;
  supCapture();
  supOpenWa(supBuildMessage([supItemFor(s)], supContactForMessage()));
}

function supFirstMissing(services){
  for(let i = 0; i < services.length; i++){
    const s = services[i];
    const qs = s.q || [];
    for(let j = 0; j < qs.length; j++){
      const q = qs[j];
      if(q.opt) continue;
      const raw = supAnswers[supAnsKey(s.key, q.id)];
      const val = Array.isArray(raw) ? raw.join("") : String(raw == null ? "" : raw).trim();
      if(!val) return { s: s, q: q };
    }
  }
  return null;
}

function supSend(){
  supCapture();
  supHideError();

  const services = supPicked.map(supSvc).filter(Boolean);
  if(!services.length){
    supShowError(supTr("עוד לא סימנת שירות. סמן ✓ על שירות אחד לפחות.",
                       "Nothing is ticked yet. Tick ✓ at least one service."));
    return;
  }

  /* ראה ההערה ב-supRenderPanel: חובה רק כשנבחר שירות אחד. */
  if(services.length === 1){
    const miss = supFirstMissing(services);
    if(miss){
      supShowError(supTr("חסרה תשובה — ","Missing an answer — ") + supName(miss.s) + ": " +
                   supTr(miss.q.he, miss.q.en));
      const el = document.getElementById("q_" + miss.s.key + "_" + miss.q.id);
      if(el){
        const d = el.closest("details");
        if(d) d.open = true;
        el.scrollIntoView({ behavior:"smooth", block:"center" });
        const f = el.matches('[data-qtype="multi"]') ? el.querySelector("input") : el;
        if(f && f.focus) f.focus();
      }
      return;
    }
  }

  const name  = String(supContactState.name || "").trim();
  const phone = supNormPhone(supContactState.phone);
  /* אותה בדיקת טלפון כמו ב-checkout.js, כדי שלא יהיו שני תקנים לאותו שדה. */
  if(name.length < 2 || !/^0\d{8,9}$/.test(phone)){
    supShowError(supTr("נא למלא שם וטלפון תקין (למשל 050-0000000).",
                       "Please fill in a name and a valid phone number (e.g. 050-0000000)."));
    const bad = document.getElementById(name.length < 2 ? "supCName" : "supCPhone");
    if(bad) bad.focus();
    return;
  }

  supOpenWa(supBuildMessage(services.map(supItemFor),
    { name: name, phone: phone, email: String(supContactState.email || "").trim() }));
}

/* ==================== בחירה ==================== */
function supToggle(key, on){
  if(!supSvc(key)) return;
  supCapture();
  const i = supPicked.indexOf(key);
  if(on  && i === -1) supPicked.push(key);
  if(!on && i !== -1) supPicked.splice(i, 1);
  supAfterChange();
}

function supClearAll(){
  supCapture();
  supPicked = [];
  supAfterChange();
}

function supAfterChange(){
  supSyncCards();
  supSyncCatBadges();
  supRenderPanel();
  supSyncJump();
  /* קישור ישיר שאפשר לשלוח: support.html?service=diagnostics,clean-thermal */
  try{
    history.replaceState(null, "", supPicked.length
      ? "support.html?service=" + supPicked.map(encodeURIComponent).join(",")
      : "support.html");
  }catch(e){}
}

function supSyncJump(){
  const btn = document.getElementById("supJump");
  if(!btn) return;
  const n = supPicked.length;
  if(!n || supPanelSeen){ btn.hidden = true; return; }
  btn.innerHTML = `<span>${supEsc(supTr("המשך לפנייה","Go to request"))}</span>` +
                  `<span class="sup-jump-n">${n}</span>`;
  btn.hidden = false;
}

/* ==================== תרגום ומעבר שפה ==================== */
function supApplyI18n(){
  document.querySelectorAll("[data-he]").forEach(el => {
    const v = LANG === "en" ? el.dataset.en : el.dataset.he;
    if(v != null) el.textContent = v;
  });
  document.querySelectorAll("[data-ph-he]").forEach(el => {
    el.placeholder = LANG === "en" ? el.dataset.phEn : el.dataset.phHe;
  });
  const ft = document.getElementById("footerText");
  if(ft) ft.textContent = t("footerText");
  renderFooterLegal();
  document.querySelectorAll(".lang-btn").forEach(b => b.classList.toggle("active", b.dataset.lang === LANG));
}

function setLang(lang){
  if(lang === LANG) return;
  supCapture();
  supDropLocalizedAnswers();
  setLangCore(lang);
  supApplyI18n();
  supRenderCats();
  supRenderCatalog();
  supSyncCatBadges();
  supRenderPanel();
  supSyncJump();
  supSpy();
  /* ⚠️ ההדר נבנה פעם אחת ב-site-header.js ולא מתרגם את עצמו מחדש.
     בונים אותו שוב כדי שהניווט יתחלף יחד עם הדף. */
  const header = document.querySelector("header");
  if(header && typeof buildSiteHeader === "function"){
    delete header.dataset.shBuilt;
    buildSiteHeader();
  }
  document.querySelectorAll(".lang-btn").forEach(b => b.classList.toggle("active", b.dataset.lang === LANG));
}

/* ==================== איתחול ==================== */
/* ה-header של האתר הוא sticky, וגובהו משתנה בין מובייל לדסקטופ. מודדים
   אותו פעם אחת (ובכל שינוי גודל) כדי שרצועת הקטגוריות תיצמד *מתחתיו*
   ולא תיעלם מאחוריו, ושקפיצה לקטגוריה לא תסתיים מתחת לשניהם. */
function supSyncHeaderHeight(){
  const h = document.querySelector("header");
  if(!h) return;
  const px = Math.round(h.getBoundingClientRect().height);
  if(px > 0) document.documentElement.style.setProperty("--sup-headh", px + "px");
}

/* צביעת הצ'יפ של הקטגוריה שנמצאת במסך. עם 20 כרטיסים קל מאוד לאבד
   את המיקום, והרצועה הדביקה היא הדבר היחיד שקבוע על המסך. */
function supSpy(){
  if(!("IntersectionObserver" in window)) return;
  if(supSpyObs){ supSpyObs.disconnect(); supSpyObs = null; }
  const secs = Array.prototype.slice.call(document.querySelectorAll(".sup-sec"));
  if(!secs.length) return;

  const head = document.querySelector("header");
  const top  = Math.round((head ? head.getBoundingClientRect().height : 85) + 74);
  const seen = Object.create(null);

  supSpyObs = new IntersectionObserver(entries => {
    entries.forEach(e => { seen[e.target.id] = e.isIntersecting; });
    let cur = "";
    for(let i = 0; i < secs.length; i++){
      if(seen[secs[i].id]){ cur = secs[i].id; break; }
    }
    document.querySelectorAll(".sup-chip").forEach(ch =>
      ch.classList.toggle("is-cur", !!cur && ch.dataset.jump === cur));
  }, { rootMargin: "-" + top + "px 0px -55% 0px" });

  secs.forEach(s => supSpyObs.observe(s));
}

/* הכפתור הצף נעלם ברגע שלוח הפנייה עצמו נכנס למסך — אחרת הוא מציע
   לגלול למקום שכבר רואים. */
function supWatchPanel(){
  const panel = document.getElementById("supPanel");
  if(!panel || !("IntersectionObserver" in window)) return;
  new IntersectionObserver(entries => {
    entries.forEach(e => { supPanelSeen = e.isIntersecting; });
    supSyncJump();
  }, { rootMargin: "0px 0px -80px 0px" }).observe(panel);
}

function supInit(){
  supApplyI18n();
  supRenderCats();
  supRenderCatalog();
  supRenderPanel();
  supSyncHeaderHeight();
  /* ההדר נבנה ב-site-header.js שרץ לפנינו, אבל הלוגו מוחלף ב-sprite.js
     והגופנים נטענים מאוחר — שתי סיבות שגובה ההדר ישתנה אחרי הטעינה. */
  window.addEventListener("load", () => { supSyncHeaderHeight(); supSpy(); });
  window.addEventListener("resize", supSyncHeaderHeight);

  const host = document.getElementById("supCatalog");
  if(host){
    host.addEventListener("change", e => {
      const cb = e.target.closest(".sup-tick");
      if(cb) supToggle(cb.dataset.pick, cb.checked);
    });
    host.addEventListener("click", e => {
      const q = e.target.closest("[data-quick]");
      if(!q) return;
      e.preventDefault();
      supQuickSend(q.dataset.quick);
    });
  }

  const panel = document.getElementById("supPanel");
  if(panel){
    panel.addEventListener("click", e => {
      const drop = e.target.closest("[data-drop]");
      if(drop){ supToggle(drop.dataset.drop, false); return; }
      if(e.target.closest("#supClear")){ supClearAll(); return; }
      if(e.target.closest("#supSendBtn")) supSend();
    });
    /* התצוגה המקדימה מתעדכנת תוך כדי הקלדה — הלקוח רואה בדיוק מה
       יישלח, וזו הדרך הפשוטה ביותר להראות שההודעה אכן קריאה. */
    panel.addEventListener("input",  () => { supCapture(); supUpdatePreview(); });
    panel.addEventListener("change", () => { supCapture(); supUpdatePreview(); });
  }

  const nav = document.getElementById("supCats");
  if(nav){
    nav.addEventListener("click", e => {
      const btn = e.target.closest("[data-jump]");
      if(!btn) return;
      const sec = document.getElementById(btn.dataset.jump);
      if(sec) sec.scrollIntoView({ behavior:"smooth", block:"start" });
    });
  }

  const jump = document.getElementById("supJump");
  if(jump){
    jump.addEventListener("click", () => {
      const box = document.getElementById("supPanel");
      if(box) box.scrollIntoView({ behavior:"smooth", block:"start" });
    });
  }

  /* קישור ישיר: support.html?service=diagnostics או ?service=a,b,c —
     כדי שאפשר יהיה להפנות מהאתר או מהודעה ישר לשירותים הנכונים. מי
     שהגיע דרך קישור כזה כבר בחר, ולכן נוחתים על הלוח ולא בראש הדף. */
  let want = "";
  try{ want = new URLSearchParams(location.search).get("service") || ""; }catch(e){}
  if(want){
    want.split(",").forEach(raw => {
      const k = raw.trim();
      if(k && supSvc(k) && supPicked.indexOf(k) === -1) supPicked.push(k);
    });
    if(supPicked.length){
      supSyncCards();
      supSyncCatBadges();
      supRenderPanel();
      const box = document.getElementById("supPanel");
      if(box) box.scrollIntoView({ behavior:"auto", block:"start" });
    }
  }

  supWatchPanel();
  supSyncJump();
  supSpy();
}

if(document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", supInit);
} else {
  supInit();
}


/* ==================== DvirTech Care ====================
   ⚠️ **הטבלה נבנית ב-JS ולא ב-HTML בכוונה.** אותם נתונים בדיוק מופיעים
   גם בכרטיסים וגם בטבלת ההשוואה; כתיבה כפולה ב-HTML הייתה מבטיחה
   שיום אחד אחד מהם יעודכן והשני לא. כאן יש מקור אחד — CARE_PLANS.

   ⚠️ **המחירים כאן זמניים.** היעד: קריאה מהגיליון דרך אותה תשובת
   getCatalog שכבר נטענת (קטגוריית "מנויים" ב-PRICE_LIST). עד אז
   מספר שמשתנה כאן חייב להשתנות גם ב-support.html.

   ⚠️ **אין רכישה.** ההצטרפות בתיאום ובאישור העסק — כך בתקנון, ולכן
   הכפתור פותח וואטסאפ ולא עגלה. */
/* ⚠️ **המחיר הוא שנתי; החודשי הוא רק תצוגת הפריסה.** כל המכסות
   (שעות תמיכה, בדיקת תחזוקה) הן שנתיות — מנוי חודשי היה מאפשר לממש
   שנה שלמה של הטבות בחודש הראשון ולבטל. ראה הנימוק המלא ב-PRICE_LIST
   שב-2-pricelist-picker.gs. */
const CARE_PLANS = [
  { key:"CARE", monthly:50,  yearly:599,
    priority:["רגילה","Standard"], checks:["פעם בשנה","Once a year"],
    remote:["עד שעה בשנה","Up to 1 hour a year"], discount:"5%" },
  { key:"PLUS", monthly:67,  yearly:799,
    priority:["בינונית","Raised"], checks:["פעם בשנה","Once a year"],
    remote:["עד 3 שעות בשנה","Up to 3 hours a year"], discount:"10%" },
  { key:"PRO",  monthly:92,  yearly:1099,
    priority:["גבוהה","Highest"], checks:["פעמיים בשנה","Twice a year"],
    remote:["עד 5 שעות בשנה","Up to 5 hours a year"], discount:"15%" }
];

function careMoney(n){ return n.toLocaleString("he-IL") + " ₪"; }

function careTableHtml(){
  const cls = { CARE:"c-care", PLUS:"c-plus", PRO:"c-pro" };
  const ico = { CARE:"🛡", PLUS:"⚡", PRO:"🚀" };
  const cell = (p, v) => `<td class="${cls[p.key]}">${supEsc(v)}</td>`;
  const row  = (label, get) =>
    `<tr><th scope="row">${supEsc(label)}</th>${CARE_PLANS.map(p => cell(p, get(p))).join("")}</tr>`;
  const yes = `<span class="yes">✓</span>`;

  return `
    <table>
      <caption>${supEsc(supTr("השוואה מלאה","Full comparison"))}</caption>
      <thead><tr>
        <th scope="col">${supEsc(supTr("הטבה","Benefit"))}</th>
        ${CARE_PLANS.map(p => `<th scope="col" class="${cls[p.key]}">${ico[p.key]} ${p.key}</th>`).join("")}
      </tr></thead>
      <tbody>
        <tr class="row-price"><th scope="row">${supEsc(supTr("מחיר שנתי","Yearly"))}</th>
          ${CARE_PLANS.map(p => cell(p, careMoney(p.yearly))).join("")}</tr>
        <tr><th scope="row">${supEsc(supTr("בפריסה לתשלומים","In installments"))}</th>
          ${CARE_PLANS.map(p => cell(p, supTr("כ-","~") + careMoney(p.monthly) + supTr(" לחודש"," / mo"))).join("")}</tr>
        <tr><th scope="row">${supEsc(supTr("תקופת הזכאות","Entitlement period"))}</th>
          ${CARE_PLANS.map(p => cell(p, supTr("12 חודשים","12 months"))).join("")}</tr>
        <tr><th scope="row">${supEsc(supTr("תמיכה וייעוץ טכני","Technical support & advice"))}</th>
          ${CARE_PLANS.map(p => `<td class="${cls[p.key]}">${yes}</td>`).join("")}</tr>
        ${row(supTr("קדימות בשירות","Service priority"), p => supTr(p.priority[0], p.priority[1]))}
        ${row(supTr("בדיקת תחזוקה","Maintenance check"), p => supTr(p.checks[0], p.checks[1]))}
        ${row(supTr("תמיכה מרחוק","Remote support"), p => supTr(p.remote[0], p.remote[1]))}
        ${row(supTr("הנחה על שירותי DvirTech","Discount on DvirTech services"), p => p.discount)}
        ${row(supTr("הנחה על ביקור טכנאי","Discount on technician visits"), p => p.discount)}
        <tr><th scope="row">${supEsc(supTr("סיוע מול גורם האחריות","Help with the warranty provider"))}</th>
          ${CARE_PLANS.map(p => `<td class="${cls[p.key]}">${yes}</td>`).join("")}</tr>
      </tbody>
    </table>
    <p class="care-fine">${supTr(
      "<b>מה לא כלול:</b> חלקי חילוף וחומרה, רישיונות ותוכנות, משלוחים, שחזור מידע מורכב, ונזק שנגרם משימוש בלתי תקין. <b>בדיקת התחזוקה ומכסת התמיכה ממומשות לפי פנייה שלך</b> — אין צורך להמתין למועד קבוע, והתיאום לפי זמינות. המכסה אישית, אינה נצברת משנה לשנה ואינה ניתנת להעברה או לפדיון. הקדימות היא העדפה תפעולית ואינה התחייבות לזמן תגובה. <b>החבילה אינה אחריות על החומרה</b> ואינה מאריכה את אחריות היצרן או היבואן. ההצטרפות בתיאום מראש ובאישור העסק, ולא ברכישה ישירה באתר.",
      "<b>Not included:</b> spare parts and hardware, licenses and software, shipping, complex data recovery, and damage caused by improper use. <b>The maintenance check and support allowance are used on your request</b> — no fixed date to wait for, scheduled by availability. The allowance is personal, does not roll over between years and cannot be transferred or cashed out. Priority is an operational preference, not a guaranteed response time. <b>The plan is not a hardware warranty</b> and does not extend the manufacturer's or importer's warranty. Joining is arranged in advance and subject to approval, not bought directly on the site.")}</p>`;
}

function careInit(){
  const btn = document.getElementById("careMoreBtn");
  const box = document.getElementById("careTable");
  if(btn && box){
    btn.addEventListener("click", function(){
      const open = btn.getAttribute("aria-expanded") === "true";
      btn.setAttribute("aria-expanded", String(!open));
      if(!open && !box.innerHTML) box.innerHTML = careTableHtml();
      box.hidden = open;
    });
  }
  /* ההצטרפות היא שיחה, לא עגלה — הכפתור פותח וואטסאפ עם שם המסלול. */
  document.querySelectorAll("[data-care]").forEach(function(a){
    a.addEventListener("click", function(e){
      e.preventDefault();
      const plan = a.getAttribute("data-care");
      const msg = supTr("היי דביר, אשמח לפרטים על מסלול DvirTech Care — " + plan,
                        "Hi Dvir, I'd like details about the DvirTech Care " + plan + " plan");
      window.open("https://wa.me/" + SUP_WHATSAPP_NUMBER + "?text=" + encodeURIComponent(msg), "_blank");
    });
  });
}

if(document.readyState === "loading"){
  document.addEventListener("DOMContentLoaded", careInit);
}else{
  careInit();
}
